import java.util.Scanner;
public class AgeCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        try {
            if (age < 18) {
                throw new Exception("InvalidAgeException: Age must be at least 18 years. Access denied.");
            }
            System.out.println("Access Granted! You are eligible.");
        } catch (Exception e) {
            System.out.println("Exception Caught: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}