import java.util.Scanner;
class InvalidMarksException extends Exception {
    public InvalidMarksException(String message) {
        super(message);
    }
}
public class CustomExceptionDemo {
    public static void validateMarks(double marks) throws InvalidMarksException {
        if (marks < 0 || marks > 100) {
            throw new InvalidMarksException("Invalid Marks: " + marks + ". Marks must be between 0 and 100.");
        }
        System.out.println("Marks successfully validated: " + marks);
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student marks (0 to 100): ");
        double marks = scanner.nextDouble();
        try {
            validateMarks(marks);
        } catch (InvalidMarksException e) {
            System.out.println("Custom Exception Caught: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}