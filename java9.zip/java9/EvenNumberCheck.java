import java.util.Scanner;
public class EvenNumberCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();
        try {
            if (number % 2 != 0) {
                throw new Exception("NumberIsNotEvenException: Entered number " + number + " is not an even number!");
            }
            System.out.println("Valid Input! " + number + " is an even number.");
        } catch (Exception e) {
            System.out.println("Exception Caught: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}