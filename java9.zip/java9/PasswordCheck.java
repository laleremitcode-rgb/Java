import java.util.Scanner;
public class PasswordCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String correctPassword = "admin123";
        System.out.print("Enter password: ");
        String inputPassword = scanner.nextLine();
        try {
            if (!inputPassword.equals(correctPassword)) {
                throw new Exception("Authentication Failure!");
            }
            System.out.println("Access Granted! Welcome.");
        } catch (Exception e) {
            System.out.println("Exception Caught: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}