import java.util.function.Supplier;
public class SupplierDemo {
    public static void main(String[] args) {
        Supplier<String> obj = () -> "Hello Java";
        System.out.println(obj.get());
    }
}