@FunctionalInterface
interface MyInterface {
    void display();
}
public class UserDefinedLambda {
    public static void main(String[] args) {
        MyInterface obj = () -> System.out.println("Hello from Lambda Expression");
        obj.display();
    }
}