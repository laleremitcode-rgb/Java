import java.util.function.Predicate;
public class PredicateDemo {
    public static void main(String[] args) {
        Predicate<Integer> obj = n -> n > 10;
        System.out.println(obj.test(15));
    }
}