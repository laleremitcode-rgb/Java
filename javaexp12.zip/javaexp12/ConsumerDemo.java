import java.util.function.Consumer;
public class ConsumerDemo {
    public static void main(String[] args) {
        Consumer<String> obj = name -> System.out.println("Hello " + name);
        obj.accept("Rahul");
    }
}