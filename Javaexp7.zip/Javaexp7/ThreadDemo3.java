class ForwardThread extends Thread {
    public void run() {
        for (int i = 10; i <= 20; i++) {
            System.out.println("Thread 1: " + i);
            if (i == 11) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
            }
        }
    }
}
class ReverseThread extends Thread {
    public void run() {
        for (int i = 20; i >= 1; i--) {
            System.out.println("Thread 2: " + i);
        }
    }
}
public class ThreadDemo3 {
    public static void main(String[] args) {
        ForwardThread t1 = new ForwardThread();
        ReverseThread t2 = new ReverseThread();
        t1.start();
        t2.start();
    }
}