class SumThread extends Thread {
    int[] arr;
    int sum = 0;
    SumThread(int[] arr) {
        this.arr = arr;
    }
    public void run() {
        for (int n : arr) {
            sum += n;
        }
        System.out.println("Sum = " + sum);
    }
}
public class ThreadDemo8 {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {10, 20, 30, 40, 50};
        SumThread t1 = new SumThread(a);
        SumThread t2 = new SumThread(b);
        t1.start();
        t2.start();
    }
}