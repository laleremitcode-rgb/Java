class Table implements Runnable {
    int n;
    Table(int n) {
        this.n = n;
    }
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(n + " x " + i + " = " + (n * i));
        }
    }
}
public class ThreadDemo5 {
    public static void main(String[] args) {
        Thread t1 = new Thread(new Table(2));
        Thread t2 = new Thread(new Table(3));

        t1.start();
        t2.start();
    }
}