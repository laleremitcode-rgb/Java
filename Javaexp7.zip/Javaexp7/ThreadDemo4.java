class NumberThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Number: " + i);
        }
    }
}
class AlphabetThread extends Thread {
    public void run() {
        for (char c = 'A'; c <= 'E'; c++) {
            System.out.println("Alphabet: " + c);
        }
    }
}

class SpecialThread extends Thread {
    public void run() {
        char[] ch = {'@', '#', '$', '%', '&'};
        for (char c : ch) {
            System.out.println("Special: " + c);
        }
    }
}
public class ThreadDemo4 {
    public static void main(String[] args) {
        NumberThread t1 = new NumberThread();
        AlphabetThread t2 = new AlphabetThread();
        SpecialThread t3 = new SpecialThread();

        t1.start();
        t2.start();
        t3.start();
    }
}