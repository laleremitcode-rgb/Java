import java.time.LocalDate;

public class DateOperations {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(2026, 10, 6);

        System.out.println("Original Date: " + date);

        System.out.println("After adding 5 days: " + date.plusDays(5));
        System.out.println("After subtracting 5 days: " + date.minusDays(5));

        System.out.println("After adding 2 months: " + date.plusMonths(2));
        System.out.println("After subtracting 2 months: " + date.minusMonths(2));

        System.out.println("After adding 1 year: " + date.plusYears(1));
        System.out.println("After subtracting 1 year: " + date.minusYears(1));
    }
}