import org.joda.time.DateTime;
public class JodaCurrentDateTime {
    public static void main(String[] args) {
        DateTime now = new DateTime();
        System.out.println("Current Date and Time: " + now);
    }
}