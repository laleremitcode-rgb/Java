import java.time.LocalDate;
public class DateDetails {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(2026, 10, 6);
        System.out.println("Day: " + date.getDayOfWeek());
        System.out.println("Month: " + date.getMonth());
        System.out.println("Year: " + date.getYear());
    }
}