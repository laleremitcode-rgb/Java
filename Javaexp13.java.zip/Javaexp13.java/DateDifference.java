import java.time.LocalDate;
import java.time.Period;
public class DateDifference {
    public static void main(String[] args) {
        LocalDate date1 = LocalDate.of(2026, 1, 1);
        LocalDate date2 = LocalDate.of(2026, 10, 6);
        Period difference = Period.between(date1, date2);
        System.out.println("Difference: " 
                + difference.getMonths() + " months and "
                + difference.getDays() + " days");
    }
}