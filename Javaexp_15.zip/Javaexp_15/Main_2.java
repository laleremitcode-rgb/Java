import java.util.HashSet;
public class Main_2 {
    public static void main(String[] args) {
        HashSet<String> items = new HashSet<>();
        System.out.println("Adding Java: " + items.add("Java"));
        System.out.println("Adding Python: " + items.add("Python"));
        System.out.println("Adding Java again: " + items.add("Java"));
        System.out.println("HashSet elements: " + items);
    }
}