import java.util.*;
public class Main_1 {
    public static void main(String[] args) {
        Set<String> set = new HashSet<>();
        set.add("Apple");
        set.add("Banana");
        set.add("Cherry");
        System.out.println("Set: " + set);
        System.out.println("Contains Banana? " + set.contains("Banana"));
        set.remove("Banana");
        System.out.println("After Delete: " + set);
    }
}