import java.util.HashSet;
public class Main3 {
    public static void main(String[] args) {
        HashSet<String> employees = new HashSet<>();
        employees.add("John");
        employees.add("Alice");
        employees.add("Bob");
        for (String name : employees) {
            System.out.println(name);
        }
    }
}