import java.util.*;

public class Main_5 {
    public static void main(String[] args) {
        HashSet<String> set = new HashSet<>(Arrays.asList("Red", "Green", "Blue"));
        List<String> list = new ArrayList<>(set);
        System.out.println("Converted ArrayList: " + list);
        for (String color : list) {
            System.out.println(color);
        }
    }
}