import java.util.*;
public class Main5 {
    public static void main(String[] args) {
        ArrayList<Integer> nums = new ArrayList<>(Arrays.asList(40, 10, 30, 20));
        System.out.println("Before: " + nums);
        Collections.sort(nums);
        System.out.println("After:  " + nums);
    }
}