import java.util.*;
public class Main1 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        System.out.println("List: " + list);
        System.out.println("Contains Banana? " + list.contains("Banana"));
        list.remove("Banana");
        System.out.println("After Delete: " + list);
    }
}