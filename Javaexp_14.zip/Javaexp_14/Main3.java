import java.util.LinkedList;

public class Main3 {
    public static void main(String[] args) {
        LinkedList<Integer> nums = new LinkedList<>();

        nums.add(10);
        nums.add(20);
        nums.addFirst(5);

        nums.removeLast();

        for (int n : nums) {
            System.out.println(n);
        }
    }
}