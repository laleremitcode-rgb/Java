import java.util.*;
public class Main4 {
    public static void main(String[] args) {
        List<Integer> arrList = new ArrayList<>();
        List<Integer> linkList = new LinkedList<>();
        for (int i = 1; i <= 5; i++) {
            arrList.add(i);
            linkList.add(i);
        }
        System.out.println("ArrayList:  " + arrList);
        System.out.println("LinkedList: " + linkList);
        System.out.println("ArrayList size: " + arrList.size());
        System.out.println("LinkedList size: " + linkList.size());
    }
}