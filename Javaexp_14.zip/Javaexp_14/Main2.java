import java.util.ArrayList;
public class Main2 {
    public static void main(String[] args) {
        ArrayList<String> students = new ArrayList<>();
        students.add("Alice");
        students.add("Bob");
        students.add("Charlie");
        for (String name : students) {
            System.out.println(name);
        }
    }
}