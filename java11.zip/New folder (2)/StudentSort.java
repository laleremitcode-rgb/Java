import java.util.ArrayList;
import java.util.Collections;
public class StudentSort {
    public static void main(String[] args) {
        ArrayList<String> students = new ArrayList<>();
        students.add("Rahul");
        students.add("Amit");
        students.add("Sneha");
        students.add("Priya");
        students.add("Neha");
        Collections.sort(students, (a, b) -> a.compareTo(b));
        System.out.println("Students in alphabetical order:");
        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i));
        }
    }
}