interface Message {
    void display();
}
public class LambdaNoParameter {
    public static void main(String[] args) {

        Message msg = () -> System.out.println("Hello, Lambda Expression!");

        msg.display();
    }
}